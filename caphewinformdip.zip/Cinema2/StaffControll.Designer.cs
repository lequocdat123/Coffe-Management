﻿namespace CoffeShopManagerment
{
    partial class StaffControll
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            this.grdEmployee = new System.Windows.Forms.DataGridView();
            this.clID_Employee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clName_Employee = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clDateofBirth = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clusername = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clpassword = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnDelete_Employee = new System.Windows.Forms.Button();
            this.btnInsert_Employee = new System.Windows.Forms.Button();
            this.btnEdit_Employee = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txt_Dateofbirth = new System.Windows.Forms.TextBox();
            this.lbl_Dateofbirth = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.txt_Password = new System.Windows.Forms.TextBox();
            this.lbl_Password = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.txt_Username = new System.Windows.Forms.TextBox();
            this.lbl_Username = new System.Windows.Forms.Label();
            this.panel26 = new System.Windows.Forms.Panel();
            this.txt_IDEmployee = new System.Windows.Forms.TextBox();
            this.lblIDEmployee = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.txt_NameEmployee = new System.Windows.Forms.TextBox();
            this.lbl_NameEmployee = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grdEmployee)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel25.SuspendLayout();
            this.SuspendLayout();
            // 
            // grdEmployee
            // 
            this.grdEmployee.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdEmployee.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grdEmployee.ColumnHeadersHeight = 50;
            this.grdEmployee.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.grdEmployee.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clID_Employee,
            this.clName_Employee,
            this.clDateofBirth,
            this.clusername,
            this.clpassword});
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.grdEmployee.DefaultCellStyle = dataGridViewCellStyle7;
            this.grdEmployee.EnableHeadersVisualStyles = false;
            this.grdEmployee.Location = new System.Drawing.Point(13, 77);
            this.grdEmployee.Name = "grdEmployee";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdEmployee.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            this.grdEmployee.RowHeadersVisible = false;
            this.grdEmployee.RowTemplate.Height = 25;
            this.grdEmployee.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdEmployee.Size = new System.Drawing.Size(909, 308);
            this.grdEmployee.TabIndex = 3;
            this.grdEmployee.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdEmployee_CellClick);
            // 
            // clID_Employee
            // 
            this.clID_Employee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clID_Employee.DataPropertyName = "ID";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clID_Employee.DefaultCellStyle = dataGridViewCellStyle2;
            this.clID_Employee.HeaderText = "ID";
            this.clID_Employee.Name = "clID_Employee";
            this.clID_Employee.ReadOnly = true;
            this.clID_Employee.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // clName_Employee
            // 
            this.clName_Employee.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clName_Employee.DataPropertyName = "Name";
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clName_Employee.DefaultCellStyle = dataGridViewCellStyle3;
            this.clName_Employee.HeaderText = "Name";
            this.clName_Employee.Name = "clName_Employee";
            this.clName_Employee.ReadOnly = true;
            this.clName_Employee.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.clName_Employee.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // clDateofBirth
            // 
            this.clDateofBirth.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clDateofBirth.DataPropertyName = "Dateofbirth";
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clDateofBirth.DefaultCellStyle = dataGridViewCellStyle4;
            this.clDateofBirth.HeaderText = "Date of birth";
            this.clDateofBirth.Name = "clDateofBirth";
            this.clDateofBirth.ReadOnly = true;
            this.clDateofBirth.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // clusername
            // 
            this.clusername.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clusername.DataPropertyName = "Username";
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clusername.DefaultCellStyle = dataGridViewCellStyle5;
            this.clusername.HeaderText = "Username";
            this.clusername.Name = "clusername";
            this.clusername.ReadOnly = true;
            this.clusername.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // clpassword
            // 
            this.clpassword.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.clpassword.DataPropertyName = "Password";
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clpassword.DefaultCellStyle = dataGridViewCellStyle6;
            this.clpassword.HeaderText = "Password";
            this.clpassword.Name = "clpassword";
            this.clpassword.ReadOnly = true;
            this.clpassword.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Tahoma", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(940, 53);
            this.label1.TabIndex = 5;
            this.label1.Text = "      Staff Data";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = global::CoffeShopManagerment.Properties.Resources.toppng1;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(3, 19);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 45);
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.BackgroundImage = global::CoffeShopManagerment.Properties.Resources.Rectangle;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnDelete_Employee);
            this.panel1.Controls.Add(this.btnInsert_Employee);
            this.panel1.Controls.Add(this.btnEdit_Employee);
            this.panel1.Controls.Add(this.panel22);
            this.panel1.Controls.Add(this.panel24);
            this.panel1.Controls.Add(this.panel23);
            this.panel1.Controls.Add(this.panel26);
            this.panel1.Controls.Add(this.panel25);
            this.panel1.Location = new System.Drawing.Point(14, 409);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(909, 301);
            this.panel1.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(227)))), ((int)(((byte)(200)))));
            this.label4.Location = new System.Drawing.Point(813, 270);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 25);
            this.label4.TabIndex = 15;
            this.label4.Text = "Remove";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(227)))), ((int)(((byte)(200)))));
            this.label3.Location = new System.Drawing.Point(813, 179);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 25);
            this.label3.TabIndex = 16;
            this.label3.Text = "Update";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(227)))), ((int)(((byte)(200)))));
            this.label2.Location = new System.Drawing.Point(835, 82);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 25);
            this.label2.TabIndex = 17;
            this.label2.Text = "Add";
            // 
            // btnDelete_Employee
            // 
            this.btnDelete_Employee.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete_Employee.BackgroundImage = global::CoffeShopManagerment.Properties.Resources.Delete_Button;
            this.btnDelete_Employee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnDelete_Employee.FlatAppearance.BorderSize = 0;
            this.btnDelete_Employee.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnDelete_Employee.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnDelete_Employee.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnDelete_Employee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete_Employee.Location = new System.Drawing.Point(837, 219);
            this.btnDelete_Employee.Name = "btnDelete_Employee";
            this.btnDelete_Employee.Size = new System.Drawing.Size(50, 50);
            this.btnDelete_Employee.TabIndex = 13;
            this.btnDelete_Employee.UseVisualStyleBackColor = false;
            this.btnDelete_Employee.Click += new System.EventHandler(this.btnDelete_Employee_Click_1);
            // 
            // btnInsert_Employee
            // 
            this.btnInsert_Employee.BackColor = System.Drawing.Color.Transparent;
            this.btnInsert_Employee.BackgroundImage = global::CoffeShopManagerment.Properties.Resources.plus;
            this.btnInsert_Employee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnInsert_Employee.FlatAppearance.BorderSize = 0;
            this.btnInsert_Employee.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnInsert_Employee.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnInsert_Employee.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnInsert_Employee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnInsert_Employee.Location = new System.Drawing.Point(836, 27);
            this.btnInsert_Employee.Name = "btnInsert_Employee";
            this.btnInsert_Employee.Size = new System.Drawing.Size(50, 50);
            this.btnInsert_Employee.TabIndex = 14;
            this.btnInsert_Employee.UseVisualStyleBackColor = false;
            this.btnInsert_Employee.Click += new System.EventHandler(this.btnInsert_Employee_Click_1);
            // 
            // btnEdit_Employee
            // 
            this.btnEdit_Employee.BackColor = System.Drawing.Color.Transparent;
            this.btnEdit_Employee.BackgroundImage = global::CoffeShopManagerment.Properties.Resources.Update1;
            this.btnEdit_Employee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnEdit_Employee.FlatAppearance.BorderSize = 0;
            this.btnEdit_Employee.FlatAppearance.CheckedBackColor = System.Drawing.Color.Transparent;
            this.btnEdit_Employee.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.btnEdit_Employee.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.btnEdit_Employee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdit_Employee.Location = new System.Drawing.Point(836, 127);
            this.btnEdit_Employee.Name = "btnEdit_Employee";
            this.btnEdit_Employee.Size = new System.Drawing.Size(50, 50);
            this.btnEdit_Employee.TabIndex = 11;
            this.btnEdit_Employee.UseVisualStyleBackColor = false;
            this.btnEdit_Employee.Click += new System.EventHandler(this.btnEdit_Employee_Click_1);
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.dateTimePicker1);
            this.panel22.Controls.Add(this.txt_Dateofbirth);
            this.panel22.Controls.Add(this.lbl_Dateofbirth);
            this.panel22.Location = new System.Drawing.Point(3, 197);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(315, 66);
            this.panel22.TabIndex = 12;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(106, 22);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(189, 30);
            this.dateTimePicker1.TabIndex = 3;
            // 
            // txt_Dateofbirth
            // 
            this.txt_Dateofbirth.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Dateofbirth.Location = new System.Drawing.Point(106, 22);
            this.txt_Dateofbirth.Multiline = true;
            this.txt_Dateofbirth.Name = "txt_Dateofbirth";
            this.txt_Dateofbirth.Size = new System.Drawing.Size(189, 35);
            this.txt_Dateofbirth.TabIndex = 1;
            this.txt_Dateofbirth.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_Dateofbirth
            // 
            this.lbl_Dateofbirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Dateofbirth.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(227)))), ((int)(((byte)(200)))));
            this.lbl_Dateofbirth.Location = new System.Drawing.Point(-3, 28);
            this.lbl_Dateofbirth.Name = "lbl_Dateofbirth";
            this.lbl_Dateofbirth.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbl_Dateofbirth.Size = new System.Drawing.Size(103, 23);
            this.lbl_Dateofbirth.TabIndex = 0;
            this.lbl_Dateofbirth.Text = "Birth";
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.txt_Password);
            this.panel24.Controls.Add(this.lbl_Password);
            this.panel24.Location = new System.Drawing.Point(370, 154);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(315, 66);
            this.panel24.TabIndex = 9;
            // 
            // txt_Password
            // 
            this.txt_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Password.Location = new System.Drawing.Point(106, 22);
            this.txt_Password.Multiline = true;
            this.txt_Password.Name = "txt_Password";
            this.txt_Password.Size = new System.Drawing.Size(189, 35);
            this.txt_Password.TabIndex = 1;
            this.txt_Password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_Password
            // 
            this.lbl_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Password.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(227)))), ((int)(((byte)(200)))));
            this.lbl_Password.Location = new System.Drawing.Point(3, 25);
            this.lbl_Password.Name = "lbl_Password";
            this.lbl_Password.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbl_Password.Size = new System.Drawing.Size(97, 23);
            this.lbl_Password.TabIndex = 0;
            this.lbl_Password.Text = "Password";
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.txt_Username);
            this.panel23.Controls.Add(this.lbl_Username);
            this.panel23.Location = new System.Drawing.Point(367, 60);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(315, 66);
            this.panel23.TabIndex = 10;
            // 
            // txt_Username
            // 
            this.txt_Username.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Username.Location = new System.Drawing.Point(106, 22);
            this.txt_Username.Multiline = true;
            this.txt_Username.Name = "txt_Username";
            this.txt_Username.Size = new System.Drawing.Size(189, 35);
            this.txt_Username.TabIndex = 1;
            this.txt_Username.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_Username
            // 
            this.lbl_Username.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Username.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(227)))), ((int)(((byte)(200)))));
            this.lbl_Username.Location = new System.Drawing.Point(3, 25);
            this.lbl_Username.Name = "lbl_Username";
            this.lbl_Username.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbl_Username.Size = new System.Drawing.Size(97, 23);
            this.lbl_Username.TabIndex = 0;
            this.lbl_Username.Text = "User Name";
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.txt_IDEmployee);
            this.panel26.Controls.Add(this.lblIDEmployee);
            this.panel26.Location = new System.Drawing.Point(3, 5);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(315, 66);
            this.panel26.TabIndex = 7;
            // 
            // txt_IDEmployee
            // 
            this.txt_IDEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_IDEmployee.Location = new System.Drawing.Point(106, 22);
            this.txt_IDEmployee.Multiline = true;
            this.txt_IDEmployee.Name = "txt_IDEmployee";
            this.txt_IDEmployee.ReadOnly = true;
            this.txt_IDEmployee.Size = new System.Drawing.Size(189, 35);
            this.txt_IDEmployee.TabIndex = 1;
            this.txt_IDEmployee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblIDEmployee
            // 
            this.lblIDEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDEmployee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(227)))), ((int)(((byte)(200)))));
            this.lblIDEmployee.Location = new System.Drawing.Point(30, 25);
            this.lblIDEmployee.Name = "lblIDEmployee";
            this.lblIDEmployee.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblIDEmployee.Size = new System.Drawing.Size(71, 23);
            this.lblIDEmployee.TabIndex = 0;
            this.lblIDEmployee.Text = "ID";
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.txt_NameEmployee);
            this.panel25.Controls.Add(this.lbl_NameEmployee);
            this.panel25.Location = new System.Drawing.Point(3, 105);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(315, 66);
            this.panel25.TabIndex = 8;
            // 
            // txt_NameEmployee
            // 
            this.txt_NameEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NameEmployee.Location = new System.Drawing.Point(106, 22);
            this.txt_NameEmployee.Multiline = true;
            this.txt_NameEmployee.Name = "txt_NameEmployee";
            this.txt_NameEmployee.Size = new System.Drawing.Size(189, 35);
            this.txt_NameEmployee.TabIndex = 1;
            this.txt_NameEmployee.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_NameEmployee
            // 
            this.lbl_NameEmployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NameEmployee.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(227)))), ((int)(((byte)(200)))));
            this.lbl_NameEmployee.Location = new System.Drawing.Point(0, 25);
            this.lbl_NameEmployee.Name = "lbl_NameEmployee";
            this.lbl_NameEmployee.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lbl_NameEmployee.Size = new System.Drawing.Size(100, 23);
            this.lbl_NameEmployee.TabIndex = 0;
            this.lbl_NameEmployee.Text = "Name";
            // 
            // StaffControll
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(33)))), ((int)(((byte)(48)))), ((int)(((byte)(69)))));
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.grdEmployee);
            this.Name = "StaffControll";
            this.Size = new System.Drawing.Size(940, 723);
            this.Load += new System.EventHandler(this.StaffControll_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdEmployee)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView grdEmployee;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridViewTextBoxColumn clID_Employee;
        private System.Windows.Forms.DataGridViewTextBoxColumn clName_Employee;
        private System.Windows.Forms.DataGridViewTextBoxColumn clDateofBirth;
        private System.Windows.Forms.DataGridViewTextBoxColumn clusername;
        private System.Windows.Forms.DataGridViewTextBoxColumn clpassword;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnDelete_Employee;
        private System.Windows.Forms.Button btnInsert_Employee;
        private System.Windows.Forms.Button btnEdit_Employee;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox txt_Dateofbirth;
        private System.Windows.Forms.Label lbl_Dateofbirth;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.TextBox txt_Password;
        private System.Windows.Forms.Label lbl_Password;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TextBox txt_Username;
        private System.Windows.Forms.Label lbl_Username;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.TextBox txt_IDEmployee;
        private System.Windows.Forms.Label lblIDEmployee;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TextBox txt_NameEmployee;
        private System.Windows.Forms.Label lbl_NameEmployee;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}
