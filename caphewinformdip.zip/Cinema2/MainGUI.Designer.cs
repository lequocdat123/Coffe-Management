﻿namespace CoffeShopManagerment
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Logout = new System.Windows.Forms.Button();
            this.btnBookingForm = new System.Windows.Forms.Button();
            this.btnManageForm = new System.Windows.Forms.Button();
            this.btnX = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(252)))), ((int)(((byte)(243)))), ((int)(((byte)(232)))));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Logout);
            this.panel1.Controls.Add(this.btnBookingForm);
            this.panel1.Controls.Add(this.btnManageForm);
            this.panel1.Location = new System.Drawing.Point(228, 23);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(247, 454);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Montserrat", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(69, 334);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Manage";
            // 
            // Logout
            // 
            this.Logout.BackColor = System.Drawing.Color.Transparent;
            this.Logout.BackgroundImage = global::CoffeShopManagerment.Properties.Resources.btn2;
            this.Logout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Logout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Logout.FlatAppearance.BorderSize = 0;
            this.Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Logout.Font = new System.Drawing.Font("Open Sans", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Logout.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(21)))), ((int)(((byte)(32)))));
            this.Logout.Location = new System.Drawing.Point(56, 405);
            this.Logout.Name = "Logout";
            this.Logout.Size = new System.Drawing.Size(115, 30);
            this.Logout.TabIndex = 3;
            this.Logout.Text = "Logout";
            this.Logout.UseVisualStyleBackColor = false;
            this.Logout.Click += new System.EventHandler(this.Logout_Click);
            // 
            // btnBookingForm
            // 
            this.btnBookingForm.BackColor = System.Drawing.Color.Transparent;
            this.btnBookingForm.BackgroundImage = global::CoffeShopManagerment.Properties.Resources.Logo_Coffee;
            this.btnBookingForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnBookingForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBookingForm.FlatAppearance.BorderSize = 0;
            this.btnBookingForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBookingForm.Location = new System.Drawing.Point(0, 0);
            this.btnBookingForm.Name = "btnBookingForm";
            this.btnBookingForm.Size = new System.Drawing.Size(247, 204);
            this.btnBookingForm.TabIndex = 1;
            this.btnBookingForm.UseVisualStyleBackColor = false;
            this.btnBookingForm.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnManageForm
            // 
            this.btnManageForm.BackColor = System.Drawing.Color.Transparent;
            this.btnManageForm.BackgroundImage = global::CoffeShopManagerment.Properties.Resources.login_icon;
            this.btnManageForm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnManageForm.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnManageForm.FlatAppearance.BorderSize = 0;
            this.btnManageForm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnManageForm.Location = new System.Drawing.Point(65, 219);
            this.btnManageForm.Name = "btnManageForm";
            this.btnManageForm.Size = new System.Drawing.Size(115, 103);
            this.btnManageForm.TabIndex = 1;
            this.btnManageForm.UseVisualStyleBackColor = false;
            this.btnManageForm.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnX
            // 
            this.btnX.BackColor = System.Drawing.Color.Transparent;
            this.btnX.BackgroundImage = global::CoffeShopManagerment.Properties.Resources._104465339_194467221913435_3583778043675453086_n;
            this.btnX.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnX.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnX.FlatAppearance.BorderSize = 0;
            this.btnX.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnX.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnX.Location = new System.Drawing.Point(474, 1);
            this.btnX.Name = "btnX";
            this.btnX.Size = new System.Drawing.Size(27, 26);
            this.btnX.TabIndex = 0;
            this.btnX.UseVisualStyleBackColor = false;
            this.btnX.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(184)))), ((int)(((byte)(130)))), ((int)(((byte)(109)))));
            this.BackgroundImage = global::CoffeShopManagerment.Properties.Resources.bg_1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(500, 500);
            this.Controls.Add(this.btnX);
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnBookingForm;
        private System.Windows.Forms.Button btnManageForm;
        private System.Windows.Forms.Button btnX;
        private System.Windows.Forms.Button Logout;
        private System.Windows.Forms.Label label1;
    }
}