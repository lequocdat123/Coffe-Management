﻿using System;
using DTO;

public class Class1
{
	public Class1()
	{
		Bill_DTO dt = new Bill_DTO();
	}
}
